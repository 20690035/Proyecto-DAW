<?php

include 'conexion_usuarios2.php';

$correo = $_POST['correo'];
$contra = $_POST['contra'];

$validar_login = mysqli_query($conexionmedico,"SELECT * FROM users WHERE email='$correo'
and pass='$contra'");

if(mysqli_num_rows($validar_login) > 0){
    $_SESSION['user']= $correo;
    header("location: iniciomedico.php");
    exit;
}else{
    echo'
    <script>
        alert("Datos erróneos, favor de verificar");
        window.location = "index.php"
        </script>
    ';
    exit;
}

?>