<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "login2";

$conexionmedico = mysqli_connect($host, $user, $password, $database);


?>