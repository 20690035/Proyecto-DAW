<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "login";

$conexionalumno = mysqli_connect($host, $user, $password, $database);




?>