<?php
    session_start();
    if(!isset($_SESSION['usuario'])){
        session_destroy();
        die();   
    }
?>
<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="img/png" href="icon2.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar citas</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .contenedor {
            max-width: 400px;
            margin: 0 auto;
            padding: 40px;
            
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color: rgba(0, 128, 255, 0.5);
            color: white;
            border-radius: 5px;
        }

        label {
            display: block; 
            margin-top: 10px;
            color: white;
        }

        input[type="text"], select {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            
        }

        button {
            padding: 10px;
            width: 35%;
            
    margin-top: 20px;
    border: none;
    border-radius: 3px;
    font-size: 14px;
    background: #00a2ff;
    font-weight: 600;
    cursor: pointer;
    color: white;
    outline: none;
        }

        
    </style>
</head>
<body background="tecno.jpg">
    <div class="contenedor">
        <center><img src="icon2.png" width="90px" height="90px" /><h2>Agendar cita</h2> </center>
        
        <br>
        <form>
            <label for="nombre">Nombre Completo</label>
            <input type="text" id="nombre" name="nombre" placeholder="Juan Pérez Martínez">

            <br><br><label for="control">N° de Control</label>
            <input type="text" id="control" name="control" placeholder="20690123">

            <br><br><label for="carrera">Carrera</label>
            <input type="text" id="carrera" name="carrera" placeholder="IIND, ISC, IAMB, IIA o IGE">

            <br><br><label for="correo">Correo</label>
            <input type="text" id="correo" name="correo" placeholder="20690123@tecvalles.mx">

            <br><br><label for="motivo">Motivo de la cita</label>
            <input type="text" id="motivo" name="motivo"  placeholder="Nauseas, Dolor de cabeza, Fiebre...">

            <br><br><label for="nivel">Nivel de urgencia</label>
            <input type="text" id="nivel" name="nivel" placeholder="Bajo, Medio o Alto">

            <br><br><label for="nivel">Escoja un turno de atención</label>
            <input type="text" id="nivel" name="nivel" placeholder="Matutino o Vespertino">

            <center><h4>El médico se pondrá en contacto contigo mediante tu correo para informarte el día y la hora de tu cita.</h4> </center>

            <center><button type="submit">📝 Registrar</button></center>
            <center><button type="button" onclick="location.href='inicioalumno.php'">🏠 Inicio</button></center>
            
        </form>
    </div>
</body>
</html>