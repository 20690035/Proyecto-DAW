<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="img/png" href="icon2.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitud de cita</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .contenedor {
            max-width: 400px;
            margin: 0 auto;
            padding: 40px;
            
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color: rgba(0, 128, 255, 0.5);
            color: white;
            border-radius: 5px;
        }

        label {
            display: block; 
            margin-top: 10px;
            color: white;
        }

        input[type="text"], select {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            
        }

        button {
            padding: 10px;
            width: 35%;
            
    margin-top: 20px;
    border: none;
    border-radius: 3px;
    font-size: 14px;
    background: #00a2ff;
    font-weight: 600;
    cursor: pointer;
    color: white;
    outline: none;
        }

        
    </style>
</head>
<body background="tecno.jpg">
    <div class="contenedor">
        <center><img src="icon2.png" width="90px" height="90px" /><h2>Solicitud de cita</h2> </center>
        
        <br>
        <form method="POST">

            <?php
            include "conexion_citas.php";
            include "registro_cita.php";
            ?>
            
            <label for="correo">Correo</label>
            <input type="text" id="correo" name="correo" placeholder="20690123@tecvalles.mx">

            <label for="motivo">Motivo de la visita</label>
            <input type="text" id="motivo" name="motivo" placeholder="Dolor estomacal">

            <br><label for="nivel">Nivel de Urgencia</label>
            <select id="nivel" name="nivel">
            <option value="Bajo">😷 Bajo</option>
            <option value="Medio">🤕 Medio</option>
            <option value="Alto">😫 Alto</option>
            </select>

            <br><label for="horario">Dia y hora que desea solicitar</label>
            <input type="datetime-local" id="horario" name="horario" placeholder="02-09-2001 2:00pm">

            <br><label for="estado">Estado de la cita</label>
            <select id="estado" name="estado">
            <option value="Pendiente">⌚ Pendiente</option>
            </select>
            
            <br><br>
            <center><button type="submit" name="btnregistrar" value="ok">📤 Enviar</button></center>
            <center><button type="button" onclick="location.href='inicioalumno.php'">🏠 Inicio</button></center>
            
        </form>
    </div>
</body>
</html>