<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="img/png" href="icon2.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Expediente</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .contenedor {
            max-width: 400px;
            margin: 0 auto;
            padding: 40px;
            
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color: rgba(0, 128, 255, 0.5);
            color: white;
            border-radius: 5px;
        }

        label {
            display: block; 
            margin-top: 10px;
            color: white;
        }

        input[type="text"], select {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            
        }

        button {
            padding: 10px;
            width: 35%;
            
    margin-top: 20px;
    border: none;
    border-radius: 3px;
    font-size: 14px;
    background: #00a2ff;
    font-weight: 600;
    cursor: pointer;
    color: white;
    outline: none;
        }

        
    </style>
</head>
<body background="tecno.jpg">
    <div class="contenedor">
        <center><img src="icon2.png" width="90px" height="90px" /><h2>Registro de expediente</h2> </center>
        
        <br>
        <form method="POST">

            <?php
            include "conexion_expedientes.php";
            include "registro_expe.php";
            ?>

            <label for="nombre">Nombre Completo</label>
            <input type="text" id="nombre" name="nombre" placeholder="Juan Pérez Martínez">

            <br><br><label for="nocontrol">N° de Control</label>
            <input type="text" id="nocontrol" name="nocontrol" placeholder="20690123">

            <br><br><label for="carrera">Carrera</label>
            <select id="carrera" name="carrera">
            <option value="IIND">IIND</option>
            <option value="ISC">ISC</option>
            <option value="IAMB">IAMB</option>
            <option value="IIA">IIA</option>
            <option value="IGE">IGE</option>
            </select>

            <br><br><label for="nacimiento">Fecha de nacimiento</label>
            <input type="date" id="nacimiento" name="nacimiento" placeholder="02-09-2001">

            <br><br><label for="afiliacion">Afiliación médica</label>
            <input type="text" id="afiliacion" name="afiliacion"  placeholder="IMSS, ISSSTE o algún otro">

            <br><br><label for="nss">NSS</label>
            <input type="text" id="nss" name="nss" placeholder="22 89 66 1939 3">

            <br><br><label for="correo">Correo</label>
            <input type="text" id="correo" name="correo" placeholder="20690123@tecvalles.mx">

            <br><br><label for="contra">Contra</label>
            <input type="password" id="contra" name="contra" placeholder="1234">

            <br><br><label for="contacto">Contacto de emergencia</label>
            <input type="text" id="contacto" name="contacto" placeholder="481 123 4567">
            
            <br><br><label for="enfermedades">Enfermedades Cronicas</label>
            <select name="enfermedades" id="enfermedades">
                <option value="Cardiovasculares">Cardiovasculares</option>
                <option value="Respiratorias">Respiratorias</option>
                <option value="Cancer">Cancer</option>
                <option value="Diabete">Diabetes</option>
                <option value="Ninguna">Ninguna</option>
            </select>
            
            <br><br><label for="alergias">Alergias</label>
            <input type="text" id="alergias" name="alergias" placeholder="Farmacos, Animales...">

            

            <center><button type="submit" name="btnregistrar" value="ok">📝 Registrar</button></center>
            <center><button type="button" onclick="location.href='expedientes.php'">🗃️ Expedientes</button></center>
            <center><button type="button" onclick="location.href='iniciomedico.php'">🏠 Inicio</button></center>
            
        </form>
    </div>
</body>
</html>