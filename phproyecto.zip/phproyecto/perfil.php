<?php

    session_start();

    if(!isset($_SESSION['usuario'])){
        session_destroy();
        die();
        
    }

   

?>
    
<?php
   
    include 'conexion_usuarios.php';
    $correo = $_SESSION['usuario'];

    $sql = "SELECT nombre, nocontrol, carrera, nacimiento, afiliacion, nss, correo, contra, contacto, enfermedades, alergias FROM alumnos WHERE correo='".$correo."'";
    $resultado=$conexionalumno->query($sql);

    while($data=$resultado->fetch_assoc()){

        $nombre = $data['nombre'];
        $nocontrol = $data['nocontrol'];
        $carrera = $data['carrera'];
        $nacimiento = $data['nacimiento'];
        $afiliacion = $data['afiliacion'];
        $nss = $data['nss'];
        $correo = $data['correo'];
        $contra = $data['contra'];
        $contacto = $data['contacto'];
        $enfermedades = $data['enfermedades'];
        $alergias = $data['alergias'];

    }

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="img/png" href="icon2.png">
    <title>Inicio</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .contenedor {
            height: 700px;
            display: flex;
        }
        .izquierda {
            width: 300px;
            background-color: lightblue;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-family: 'Roboto', sans-serif;
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color: rgba(0, 128, 255, 0.5);
            color: white;
            border-radius: 5px;
        }
        .derecha {
            width: 1200px;
            background-color: ultramarine;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Roboto', sans-serif;
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color:white;
            color: black;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            width: 60%;
            
    margin-top: 40px;
    border: none;
    border-radius: 3px;
    font-size: 14px;
    background: #00a2ff;
    font-weight: 600;
    cursor: pointer;
    color: white;
    outline: none;
        }
    </style>
    
</head>
<body background="tecno.jpg">
    <div class="contenedor">
        <div class="izquierda">
            <img src="icon2.png" width="100px" height="100px" />
            <button type="button" onclick="location.href='inicioalumno.php'">🏠 Inicio</button>
            <button type="button" onclick="location.href='perfil.php'">📁 Mis datos</button>
            <button type="button" onclick="location.href='doctores.php'">👩‍⚕️👨‍⚕️ Doctores</button>
            <button type="button" onclick="location.href='formulario_cita.php'">🕑 Agendar cita</button>
            <button type="button" onclick="location.href='cerrar_sesion.php'">❌ Cerrar sesión</button>
            <button type="button" onclick="location.href='terminos.php'">📋 Terminos y condiciones</button>
        </div>
        <div class="derecha">
        <center>
        <h1><img src="perfil.png" width="150px" height="150px" />   
        <h3>Nombre: <?php echo $nombre;?></h3>
        <h3>N° Control: <?php echo $nocontrol;?></h3>
        <h3>Carrera: <?php echo $carrera;?></h3>
        <h3>Fecha de nacimiento: <?php echo $nacimiento;?></h3>
        <h3>Institución afiliada: <?php echo $afiliacion;?></h3>
        <h3>N° de seguridad social: <?php echo $nss;?></h3>
        <h3>Correo instucional: <?php echo $correo;?></h3>
        <h3>Contacto: <?php echo $contacto;?></h3>
        <h3>Enfermedades: <?php echo $enfermedades;?></h3>
        <h3>Alergias: <?php echo $alergias;?></h3>

        </center>
    
        </div>
    </div>
</body>
</html>
