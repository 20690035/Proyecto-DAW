<?php

if(!empty($_POST["btnregistrar"])){
    if(!empty($_POST["horario"]) and !empty($_POST["estado"])){
        $id=$_POST["id"];
        $horario=$_POST["horario"];
        $estado=$_POST["estado"];
        $sql=$conexion->query("update alumnos set horario='$horario', estado='$estado' where id=$id");
        header("refresh:0;url=citas.php");
        
    }
}

?>