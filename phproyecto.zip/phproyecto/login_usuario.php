<?php

session_start();

include 'conexion_usuarios.php';

$correo = $_POST['correo'];
$contra = $_POST['contra'];

$validar_login = mysqli_query($conexionalumno,"SELECT * FROM alumnos WHERE correo='$correo'
and contra='$contra'");

if(mysqli_num_rows($validar_login) > 0){
    $_SESSION['usuario']= $correo;
    header("location: inicioalumno.php");
    exit;
}else{
    echo'
    <script>
        alert("Datos erróneos, favor de verificar");
        window.location = "index.php"
        </script>
    ';
    exit;
}

?>