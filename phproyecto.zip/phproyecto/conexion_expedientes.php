<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "expedientes";

$conexion = mysqli_connect($host, $user, $password, $database);




?>