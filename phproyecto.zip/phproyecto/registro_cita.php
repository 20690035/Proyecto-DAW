<?php
if (!empty($_POST["btnregistrar"])){
    if(!empty($_POST["correo"]) and
    !empty($_POST["motivo"]) and
    !empty($_POST["nivel"]) and
    !empty($_POST["horario"]) and
    !empty($_POST["estado"])){
        
        $correo=$_POST["correo"];
        $motivo=$_POST["motivo"];
        $nivel=$_POST["nivel"];
        $horario=$_POST["horario"];
        $estado=$_POST["estado"];

       

        $sql=$conexion->query(" insert into alumnos(correo,motivo,nivel,horario,estado)values('$correo','$motivo','$nivel','$horario','$estado')");
        if ($sql==1){
            echo '<div class="alert alert-primary">✔️𝙇𝙖 𝙨𝙤𝙡𝙞𝙘𝙞𝙩𝙪𝙙 𝙛𝙪𝙚 𝙚𝙣𝙫𝙞𝙖𝙙𝙖 𝙘𝙤𝙣 𝙚𝙭𝙞𝙩𝙤✔️<br><br>👁️‍🗨️𝘙𝘦𝘤𝘶𝘦𝘳𝘥𝘢 𝘳𝘦𝘷𝘪𝘴𝘢𝘳 𝘵𝘶 𝘤𝘰𝘳𝘳𝘦𝘰 𝘱𝘢𝘳𝘢 𝘷𝘦𝘳 𝘭𝘢 𝘤𝘰𝘯𝘧𝘪𝘳𝘮𝘢𝘤𝘪𝘰́𝘯 𝘥𝘦 𝘵𝘶 𝘤𝘪𝘵𝘢, 𝘺𝘢 𝘲𝘶𝘦 𝘭𝘢 𝘧𝘦𝘤𝘩𝘢 𝘺 𝘩𝘰𝘳𝘢 𝘱𝘶𝘦𝘥𝘦𝘯 𝘺𝘢 𝘦𝘴𝘵𝘢𝘳 𝘴𝘰𝘭𝘪𝘤𝘪𝘵𝘢𝘥𝘢𝘴.👁️‍🗨️</div>';
        } else{
            echo '<div class="alert alert-danger">❌𝙉𝙤 𝙨𝙚 𝙥𝙪𝙙𝙤 𝙧𝙚𝙜𝙞𝙨𝙩𝙧𝙖𝙧❌</div>';
        }


    }else{
        echo "❗❗❗ 𝙃𝙖𝙮 𝙪𝙣𝙤 𝙤 𝙫𝙖𝙧𝙞𝙤𝙨 𝙘𝙖𝙢𝙥𝙤𝙨 𝙞𝙣𝙘𝙤𝙢𝙥𝙡𝙚𝙩𝙤𝙨 ❗❗❗";
    }

}