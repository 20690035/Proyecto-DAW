<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="img/png" href="icon2.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://kit.fontawesome.com/01ddab6875.js" crossorigin="anonymous"></script>
    <title>Citas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .container {
            height: 700px;
            display: flex;
        }
        .left {
            width: 300px;
            background-color: lightblue;
            color: white;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            font-family: 'Roboto', sans-serif;
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color: rgba(0, 128, 255, 0.5);
            color: white;
            border-radius: 5px;
        }
        .right {
            width: 1200px;
            background-color: ultramarine;
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Roboto', sans-serif;
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color:white;
            color: #00a2ff;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            width: 60%;
            
    margin-top: 40px;
    border: none;
    border-radius: 3px;
    font-size: 14px;
    background: #00a2ff;
    font-weight: 600;
    cursor: pointer;
    color: white;
    outline: none;
        }


        .butto {
            padding: 8px;
            width: 60%;
            
    margin-top: 4px;
    border: none;
    border-radius: 3px;
    font-size: 14px;
    background: #00a2ff;
    font-weight: 600;
    cursor: pointer;
    color: white;
    outline: none;
        }

    </style>
</head>
<body background="tecno.jpg">
    <div class="container">
        <div class="left">
            <img src="icon2.png" width="100px" height="100px" />
            <button type="button" onclick="location.href='iniciomedico.php'">🏠 Inicio</button>
            <button type="button" onclick="location.href='pacientes.php'">🤕 Pacientes</button>
            <button type="button" onclick="location.href='cerrar_sesion.php'">❌ Cerrar sesión</button>
        </div>
        <div class="right">
        
        <table class="table">
  <thead>
    
    <tr>
        
      <th scope="col"></th>
      <th scope="col">ID</th>
      <th scope="col">Correo</th>
      <th scope="col">Motivo</th>
      <th scope="col">Nivel</th>
      <th scope="col">Horario</th>
      <th scope="col">Estado</th>
    </tr>
  </thead>
  <tbody>
    <?php
    include "conexion_citas.php";
    $sql=$conexion->query(" select * from alumnos ");
    while($datos=$sql->fetch_object()){?>

<tr>
  <th scope="row"></th>
  <td><?= $datos->id?> </td>
  <td><?= $datos->correo?> </td>
  <td><?= $datos->motivo?> </td>
  <td><?= $datos->nivel?> </td>
  <td><?= $datos->horario?> </td>
  <td><?= $datos->estado?> </td>
  <td>
    <button class="butto" type="button" onclick="location.href='editar_cita.php?id=<?= $datos->id ?>'">✏️</button>
    <button class="butto" type="button" onclick="window.open('https://mail.google.com/mail/?view=cm&to=<?=$datos->correo?>&subject=CITA&body=Hola, estudiante. Solo para confirmarle que su cita en el consultorio del TecValles será el día / /  a las', '_blank')">✉️</button>



  </td>
</tr>

    <?php }
    ?>
    
    
  </tbody>
</table>

        </div>
    </div>
</body>
</html>
