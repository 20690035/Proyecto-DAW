<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "citas";

$conexion = mysqli_connect($host, $user, $password, $database);




?>