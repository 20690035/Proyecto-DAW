<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Aumentar y disminuir botones</title>
</head>
<body>

  <div style="width: 200px; height: 100px; background-color: blue;">
    <p style="font-size: 18px;">Cantidad: <span id="cantidad">0</span></p>
    <button type="button" onclick="aumentar()">Aumentar</button>
    <button type="button" onclick="disminuir()">Disminuir</button>
  </div>

  <script>
    function aumentar() {
      var cantidad = document.getElementById("cantidad").innerHTML;
      cantidad = parseInt(cantidad) + 1;
      document.getElementById("cantidad").innerHTML = cantidad;
    }

    function disminuir() {
      var cantidad = document.getElementById("cantidad").innerHTML;
      cantidad = parseInt(cantidad) - 1;
      if (cantidad < 0) {
        cantidad = 0;
      }
      document.getElementById("cantidad").innerHTML = cantidad;
    }
  </script>

</body>
</html>
