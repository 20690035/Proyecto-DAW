<?php

$host = "localhost";
$user = "root";
$password = "";
$database = "expedientes";

$conexionalumno = mysqli_connect($host, $user, $password, $database);




?>