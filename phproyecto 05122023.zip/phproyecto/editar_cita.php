<?php
include "conexion_citas.php";
$id=$_GET["id"];

$sql=$conexion->query(" select * from alumnos where id=$id ");

?>


<!DOCTYPE html>
<head>
    <meta charset="UTF-8">
    <link rel="icon" type="img/png" href="icon2.png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agendar cita</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
        }

        .contenedor {
            max-width: 400px;
            margin: 0 auto;
            padding: 40px;
            
            -webkit-backdrop-filter: blur(10px);
    backdrop-filter: blur(8px);
    background-color: rgba(0, 128, 255, 0.5);
            color: white;
            border-radius: 5px;
        }

        label {
            display: block; 
            margin-top: 10px;
            color: white;
        }

        input[type="text"], select {
            width: 95%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            
        }

        button {
            padding: 10px;
            width: 35%;
            
    margin-top: 20px;
    border: none;
    border-radius: 3px;
    font-size: 14px;
    background: #00a2ff;
    font-weight: 600;
    cursor: pointer;
    color: white;
    outline: none;
        }

        
    </style>
</head>
<body background="tecno.jpg">
    <div class="contenedor">
        <center><img src="icon2.png" width="90px" height="90px" /><h2>Agendar cita</h2> </center>
        
        <br>
        <form method="POST">

        <input type="hidden" name="id" value="<?= $_GET["id"] ?>">

            <?php
            include "btneditar_cita.php";
            while($datos=$sql->fetch_object()){?>

            <br><label for="horario">Dia y hora de la cita</label>
            <input type="datetime-local" id="horario" name="horario" value="<?= $datos->horario ?>">

            <br><label for="estado">Estado de la cita</label>
            <select id="estado" name="estado" value="<?= $datos->estado ?>">
            <option value="⌚ Pendiente">⌚ Pendiente</option>
            <option value="⏳ Agendada">⏳ Agendada</option>
            <option value="✔️ Atendida">✔️ Atendida</option>
            </select>

            <?php }
            ?>
            
            
            
            <br><br>
            <center><button type="submit" name="btnregistrar" value="ok">💾 Guardar</button></center>
            <center><button type="button" onclick="location.href='citas.php'">🕑 Citas</button></center>
            
        </form>
    </div>
</body>
</html>